// app.test.js
//
const request = require('supertest');
const app = require('./app');
//
describe('Test the /test path', () => {
    test('It should respond with a 200 status code', async () => {
        const response = await request(app).get('/test');
        expect(response.statusCode).toBe(200);
    });
});
//add a test to check the response contains the words 'Test endpoint!'
test('It should respond with the message "Test endpoint!"', async () => {
    const response = await request(app).get('/test');
    expect(response.text).toBe('Test endpoint!');
});

//