const express = require('express');
const app = express();
//
app.get('/test', (req, res) => {
  res.send('Test endpoint!')
});
//
module.exports = app;
