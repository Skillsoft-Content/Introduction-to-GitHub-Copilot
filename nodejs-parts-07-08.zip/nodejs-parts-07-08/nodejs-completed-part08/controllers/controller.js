const Employee = require('../models/employee');
exports.getdefault = function(req, res){
  res.send('You are on the root route.');
};
//
exports.aboutus=function(req, res){
  res.send('You are on the about us route.');
};
//
exports.addemployee = async function(req, res) {
  try {
    const newEmployee = new Employee({
      empName: req.body.empName,
      empPass: req.body.empPass
    });
    const employee = await newEmployee.save();
    res.json(employee);
  } catch (err) {
    res.send(err);
  }
};
//
exports.getemployees= function(req, res){
  Employee.find()
    .then(employees => {
      res.json(employees);
    })
    .catch(err => {
      res.send(err);
    });
};
/* 
exports.getemployees=async function(req, res){
  const employees = await Employee.find();
  res.send(employees);
};
 */