const mongoose = require('mongoose');
mongoose.set('strictQuery', false);
require('dotenv').config();
const CONNECTION = process.env.CONNECTION;
// connect to the mongodb atlas database
(async () => {
    try {
        await mongoose.connect(CONNECTION, {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });
        console.log('Connected to MongoDB Atlas');
    } catch (error) {
        console.error('Failed to connect to MongoDB Atlas:', error);
    }
})();
// create a schema
const employeeSchema = new mongoose.Schema({
    empName: String,
    empPass: String, 
});
//
//export the model
module.exports = mongoose.model('Employee', employeeSchema);
