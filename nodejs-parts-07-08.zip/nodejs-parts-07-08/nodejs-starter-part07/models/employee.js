const mongoose = require('mongoose');
mongoose.set('strictQuery', false);
require('dotenv').config();
const CONNECTION = process.env.CONNECTION;
